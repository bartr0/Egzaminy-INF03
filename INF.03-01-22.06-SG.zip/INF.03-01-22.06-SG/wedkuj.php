<!DOCTYPE html>
<html lang="pl-PL">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styl_1.css">
    <title>Wędkowanie</title>
</head>
<body>

    <section id="banner">
            <h1>Portal dla wędkarzy</h1>
    </section>

    <section id="lewy_1">
        <h3>Ryby zamieszkujące rzeki</h3>
        <!-- order list in php -->
        <ol>
            <?php
                $conn = mysqli_connect("localhost", "root", "", "wedkowanie") or die("Błąd połączenia");
                mysqli_set_charset($conn,"utf8");
               
                $q = "SELECT nazwa, akwen, wojewodztwo FROM Ryby JOIN lowisko ON ryby.id=lowisko.Ryby_id WHERE rodzaj = 3;";
                $result = mysqli_query($conn, $q) or die("Błąd zapytania");

                while($row = mysqli_fetch_row($result)){
                    echo "<li>";
                    echo $row[0]." pływa w rzece ".$row[1].", ".$row[2];
                    echo "</li>";
                }

                mysqli_close($conn); 
            ?>
        </ol>
    </section>  
             
    <section id="prawy">
        <img src="ryba1.jpg" alt="Sum">
        <a href="kwerendy.txt">Pobierz kwerendy</a>
    </section>

    <section id="lewy_2">
        <h3>Ryby drapieżne naszych wód</h3>
        <table>
            <tr>
                <th>L.p.</th><th>Gatunek</th><th>Występowanie</th>
            </tr>
            <?php
                $conn2 = mysqli_connect("localhost", "root", "", "wedkowanie") or die("Błąd połączenia");
                mysqli_set_charset($conn2,"utf8");
                $q2 = "SELECT id, nazwa, wystepowanie FROM Ryby WHERE styl_zycia = 1;";
                $result2 = mysqli_query($conn2, $q2) or die("Błąd zapytania");

                while($row2 = mysqli_fetch_row($result2)){
                    echo "<tr>"."<td>".$row2[0]."</td>"."<td>".$row2[1]."</td>"."<td>".$row2[2]."</td>"."</tr>";

                }

                mysqli_close($conn2); 
            ?>
        </table>
    </section>    

    <section id="footer">
        <p>Stronę wykonał: 04232402197</p>
    </section>
    
</body>
</html>